package com.example.indonesia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
