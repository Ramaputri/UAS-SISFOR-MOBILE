import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://escmerpsopzkgpngfzyj.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVzY21lcnBzb3B6a2dwbmdmenlqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDQ2OTY2NDcsImV4cCI6MjAyMDI3MjY0N30.QJYTOg_r4tefGFf7FRV2eJqzBl0wyLuWGM9AkyXobJg',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'indonesia',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _future = Supabase.instance.client.from('indonesia').select();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final indonesia = snapshot.data!;
          return ListView.builder(
            itemCount: indonesia.length,
            itemBuilder: ((context, index) {
              final country = indonesia[index];
              return ListTile(
                title: Text(country['Kecamatan']),
                subtitle: Text('${country['Kabupaten']} - ${country['Provinsi']}'),
              );
            }),
          );
        },
      ),
    );
  }
}
